To import the projects in Eclipse:
1. File -> Import
2. Existing Maven Project (if you don't find this option, install the Maven plugin from Help -> Install New Software)
3. Navigate to the project's directory
4. Select the pom.xml file and click Finish

To import the projects in IntelliJ IDEA:
1. In the Welcome to IntelliJ IDEA window, choose the option Open
3. Navigate to the project's directory
2. Select the pom.xml file and click Ok
3. Choose the option Open as Project

URLs:
Spring WebFlux documentation for WebClient
https://docs.spring.io/spring/docs/current/spring-framework-reference/web-reactive.html#webflux-client

Spring 5 WebClient and WebTestClient Tutorial with Examples
https://www.callicoder.com/spring-5-reactive-webclient-webtestclient-examples/

Reactive HTTP Client With Spring 5 WebClient
https://howtoprogram.xyz/2017/10/28/reactive-http-client-spring-5-webclient/

Spring 5 WebClient
http://www.baeldung.com/spring-5-webclient