To import the projects in Eclipse:
1. File -> Import
2. Existing Maven Project (if you don't find this option, install the Maven plugin from Help -> Install New Software)
3. Navigate to the project's directory
4. Select the pom.xml file and click Finish

To import the projects in IntelliJ IDEA:
1. In the Welcome to IntelliJ IDEA window, choose the option Open
3. Navigate to the project's directory
2. Select the pom.xml file and click Ok
3. Choose the option Open as Project


Maven Central Repository
http://search.maven.org

Reactive Streams Specification
https://github.com/reactive-streams/reactive-streams-jvm

Reactor Documentation
http://projectreactor.io/docs/core/snapshot/reference/

Reactor Javadoc
http://projectreactor.io/docs/core/release/api/

Appendix A: Which operator do I need?
http://projectreactor.io/docs/core/release/reference/docs/index.html#which-operator

Appendix B: FAQ, Best Practices, and "How do I...??"
http://projectreactor.io/docs/core/release/reference/docs/index.html#faq

Lite Rx API Hands-on
https://github.com/reactor/lite-rx-api-hands-on