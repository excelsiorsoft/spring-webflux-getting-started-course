URLs:
Pluralsight Course: Spring Fundamentals
https://app.pluralsight.com/library/courses/spring-fundamentals/table-of-contents

Pluralsight Course: Introduction to Spring MVC 4
https://app.pluralsight.com/library/courses/spring-mvc4-introduction/table-of-contents

Pluralsight Course: From Collections to Streams in Java 8 Using Lambda Expressions
https://app.pluralsight.com/library/courses/java-8-lambda-expressions-collections-streams/table-of-contents

Download JDK 9:
http://www.oracle.com/technetwork/java/javase/downloads/jdk9-downloads-3848520.html

Download IntelliJ IDEA:
https://www.jetbrains.com/idea/download/

Reactive Streams website:
http://www.reactive-streams.org/

The Reactive Manifesto
https://www.reactivemanifesto.org/

ReactiveAdapterRegistry Documentation:
https://docs.spring.io/spring-framework/docs/5.0.2.RELEASE/javadoc-api/org/springframework/core/ReactiveAdapterRegistry.html

To learn more:

Reactive programming vs. Reactive systems
https://www.oreilly.com/ideas/reactive-programming-vs-reactive-systems

Notes on Reactive Programming Part I: The Reactive Landscape
https://spring.io/blog/2016/06/07/notes-on-reactive-programming-part-i-the-reactive-landscape

Java 8: Writing asynchronous code with CompletableFuture
http://www.deadcoderising.com/java8-writing-asynchronous-code-with-completablefuture/

Spring Data Kay is here
https://jaxenter.com/spring-data-kay-137782.html

The introduction to Reactive Programming you've been missing
https://gist.github.com/staltz/868e7e9bc2a7b8c1f754